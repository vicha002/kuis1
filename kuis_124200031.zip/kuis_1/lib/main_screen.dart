import 'package:flutter/material.dart';
import 'package:kuis_1/detail_view.dart';
import 'package:kuis_1/coffee_menu.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  double _rating = 4.5;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white70.withOpacity(0.8),
        appBar: AppBar(
          title: Text('List Coffee'),
          centerTitle: true,
        ),
        body: ListView.builder(
          itemBuilder: (context, index) {
            final CoffeeMenu = coffeeList[index];
            double rating;

            return InkWell(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => DetailPage(
                              CoffeList: CoffeeMenu,
                            )));
              },
              child: Card(
                elevation: 50,
                shadowColor: Colors.orangeAccent,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      height: 100,
                      // width: 80,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.0),
                        color: Colors.blueGrey,
                        image: DecorationImage(
                          fit: BoxFit.fitWidth,
                          colorFilter: ColorFilter.mode(
                              Colors.green.withOpacity(0.6), BlendMode.dstOut),
                          image: NetworkImage(CoffeeMenu.imageUrls[0]),
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            CoffeeMenu.name,
                            style: TextStyle(
                                color: Colors.orangeAccent,
                                shadows: [
                                  Shadow(
                                      color: Colors.white,
                                      blurRadius: 10,
                                      offset: Offset(2, 2))
                                ],
                                fontSize: 18,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            CoffeeMenu.nutrition,
                            style: TextStyle(
                                color: Colors.black,
                                shadows: [
                                  Shadow(
                                      color: Colors.white,
                                      blurRadius: 10,
                                      offset: Offset(2, 2))
                                ],
                                fontSize: 18,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            'Rating : ${CoffeeMenu.reviewAverage}',
                            style: TextStyle(shadows: [
                              Shadow(
                                  color: Colors.white,
                                  blurRadius: 10,
                                  offset: Offset(2, 2))
                            ], fontSize: 14, fontWeight: FontWeight.bold),
                          ),

                          SizedBox(
                            height: 3,
                          ),
                          Text(
                            CoffeeMenu.price,
                            style: TextStyle(shadows: [
                              Shadow(
                                  color: Colors.white,
                                  blurRadius: 10,
                                  offset: Offset(2, 2))
                            ], fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
          itemCount: coffeeList.length,
        ));
  }
}
